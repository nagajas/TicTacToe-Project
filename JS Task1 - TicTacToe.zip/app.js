// SubTask1

const board = document.getElementById("board");
const cells = document.getElementsByClassName("cell");
const msg = document.getElementById("msg");
const players = ["X", "O"];
let current = players[0];

// // add event listeners to each cell

function handleCellClick(event) {
  // Handle Cell Clicking Functionality
}

// SubTask2

function checkWin(current) {
  // // Check Winning conditions
}

function checkTie() {
  // // Check Tie conditions
}

// SubTask3
function restart() {
  // // Restart Game Functionality
}
